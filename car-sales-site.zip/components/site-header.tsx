import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="relative h-10 w-10 overflow-hidden rounded-md">
              <Image src="/logo.png" alt="Will's Cars Logo" fill className="object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-none">Will's</span>
              <span className="font-bold text-lg leading-none">Cars</span>
              <span className="text-xs text-muted-foreground leading-none">LUXURY</span>
            </div>
          </Link>
        </div>

        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-rollsroyce-700">
            Accueil
          </Link>
          <Link href="/vehicules" className="text-sm font-medium transition-colors hover:text-rollsroyce-700">
            Véhicules
          </Link>
          <Link href="/ajouter-vehicule" className="text-sm font-medium transition-colors hover:text-rollsroyce-700">
            Ajouter un véhicule
          </Link>
          <Link href="/contact" className="text-sm font-medium transition-colors hover:text-rollsroyce-700">
            Contact
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="border-rollsroyce-700 text-rollsroyce-700">
            <Link href="/vendre">+ Vendre</Link>
          </Button>
          <Button variant="outline" size="sm">
            Connexion
          </Button>
          <Button size="sm" className="bg-black text-white hover:bg-gray-800">
            Inscription
          </Button>
        </div>
      </div>
    </header>
  )
}
