import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AjouterVehiculePage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Ajouter un véhicule</h1>

        <Card>
          <CardHeader>
            <CardTitle>Informations du véhicule</CardTitle>
            <CardDescription>Entrez les détails de votre véhicule</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="make">Marque</Label>
                  <Select>
                    <SelectTrigger id="make">
                      <SelectValue placeholder="Sélectionnez une marque" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bmw">BMW</SelectItem>
                      <SelectItem value="mercedes">Mercedes</SelectItem>
                      <SelectItem value="audi">Audi</SelectItem>
                      <SelectItem value="rolls-royce">Rolls-Royce</SelectItem>
                      <SelectItem value="bentley">Bentley</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="model">Modèle</Label>
                  <Input id="model" placeholder="Ex: Série 7" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Année</Label>
                  <Input id="year" type="number" placeholder="Ex: 2022" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">Prix (FCFA)</Label>
                  <Input id="price" type="number" placeholder="Ex: 25000000" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mileage">Kilométrage</Label>
                  <Input id="mileage" type="number" placeholder="Ex: 15000" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fuel">Carburant</Label>
                  <Select>
                    <SelectTrigger id="fuel">
                      <SelectValue placeholder="Sélectionnez un type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="essence">Essence</SelectItem>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="hybride">Hybride</SelectItem>
                      <SelectItem value="electrique">Électrique</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="transmission">Transmission</Label>
                  <Select>
                    <SelectTrigger id="transmission">
                      <SelectValue placeholder="Sélectionnez un type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="automatique">Automatique</SelectItem>
                      <SelectItem value="manuelle">Manuelle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="color">Couleur</Label>
                  <Input id="color" placeholder="Ex: Noir" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Décrivez votre véhicule en détail..."
                  className="min-h-[150px]"
                />
              </div>

              <div className="space-y-2">
                <Label>Photos</Label>
                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  <p className="text-muted-foreground mb-2">Glissez-déposez vos photos ici ou</p>
                  <Button type="button" variant="outline">
                    Parcourir
                  </Button>
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit" className="bg-rollsroyce hover:bg-rollsroyce-800">
                  Publier l'annonce
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
