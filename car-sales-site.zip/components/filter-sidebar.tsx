"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { getUniqueValues } from "@/lib/data"

export function FilterSidebar() {
  const router = useRouter()
  const searchParams = useSearchParams()

  // Modifier les valeurs par défaut pour les prix
  const [minPrice, setMinPrice] = useState<number>(0)
  const [maxPrice, setMaxPrice] = useState<number>(50000000)
  const [minYear, setMinYear] = useState<number>(2010)
  const [maxYear, setMaxYear] = useState<number>(2023)
  const [make, setMake] = useState<string>("")
  const [fuelType, setFuelType] = useState<string>("")

  const makes = getUniqueValues("make") as string[]
  const fuelTypes = getUniqueValues("fuelType") as string[]

  const handleFilter = () => {
    const params = new URLSearchParams()

    if (make) params.set("make", make)
    if (minPrice > 0) params.set("minPrice", minPrice.toString())
    if (maxPrice < 50000000) params.set("maxPrice", maxPrice.toString())
    if (minYear > 2010) params.set("minYear", minYear.toString())
    if (maxYear < 2023) params.set("maxYear", maxYear.toString())
    if (fuelType) params.set("fuelType", fuelType)

    router.push(`/vehicules?${params.toString()}`)
  }

  const handleReset = () => {
    setMinPrice(0)
    setMaxPrice(50000000)
    setMinYear(2010)
    setMaxYear(2023)
    setMake("")
    setFuelType("")
    router.push("/vehicules")
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <Filter className="h-4 w-4" /> Filtres
        </h3>
        <Button variant="ghost" size="sm" onClick={handleReset}>
          Réinitialiser
        </Button>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="make">Marque</Label>
          <Select value={make} onValueChange={setMake}>
            <SelectTrigger id="make">
              <SelectValue placeholder="Toutes les marques" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les marques</SelectItem>
              {makes.map((make) => (
                <SelectItem key={make} value={make}>
                  {make}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="fuelType">Carburant</Label>
          <Select value={fuelType} onValueChange={setFuelType}>
            <SelectTrigger id="fuelType">
              <SelectValue placeholder="Tous les carburants" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les carburants</SelectItem>
              {fuelTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="price-range">Prix</Label>
            {/* Modifier l'affichage des prix */}
            <span className="text-sm text-muted-foreground">
              {minPrice.toLocaleString()} FCFA - {maxPrice.toLocaleString()} FCFA
            </span>
          </div>
          <div className="pt-4">
            {/* Modifier les valeurs min et max du slider de prix */}
            <Slider
              id="price-range"
              defaultValue={[minPrice, maxPrice]}
              min={0}
              max={50000000}
              step={500000}
              onValueChange={(values) => {
                setMinPrice(values[0])
                setMaxPrice(values[1])
              }}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="year-range">Année</Label>
            <span className="text-sm text-muted-foreground">
              {minYear} - {maxYear}
            </span>
          </div>
          <div className="pt-4">
            <Slider
              id="year-range"
              defaultValue={[minYear, maxYear]}
              min={2010}
              max={2023}
              step={1}
              onValueChange={(values) => {
                setMinYear(values[0])
                setMaxYear(values[1])
              }}
            />
          </div>
        </div>

        <Button className="w-full" onClick={handleFilter}>
          Appliquer les filtres
        </Button>
      </div>
    </div>
  )
}
