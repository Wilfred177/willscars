import { Mail, MapPin, MessageCircle, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"

export default function ContactPage() {
  return (
    <div className="container py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-2">Contactez-nous</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Notre équipe est à votre disposition pour répondre à toutes vos questions
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <Card>
          <CardContent className="flex flex-col items-center text-center p-6">
            <div className="h-12 w-12 rounded-full bg-bordeaux-100 flex items-center justify-center mb-4">
              <Phone className="h-6 w-6 text-bordeaux-950" />
            </div>
            <h3 className="font-semibold mb-2">Téléphone</h3>
            <p className="text-muted-foreground mb-4">Du lundi au samedi de 9h à 19h</p>
            <p className="font-medium">+225 07 8785 4165</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col items-center text-center p-6">
            <div className="h-12 w-12 rounded-full bg-bordeaux-100 flex items-center justify-center mb-4">
              <MessageCircle className="h-6 w-6 text-bordeaux-950" />
            </div>
            <h3 className="font-semibold mb-2">WhatsApp</h3>
            <p className="text-muted-foreground mb-4">Réponse rapide 7j/7</p>
            <Link
              href="https://wa.me/2250787854165"
              target="_blank"
              className="font-medium text-bordeaux-950 hover:underline"
            >
              +225 07 8785 4165
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col items-center text-center p-6">
            <div className="h-12 w-12 rounded-full bg-bordeaux-100 flex items-center justify-center mb-4">
              <Mail className="h-6 w-6 text-bordeaux-950" />
            </div>
            <h3 className="font-semibold mb-2">Email</h3>
            <p className="text-muted-foreground mb-4">Réponse sous 24h ouvrées</p>
            <p className="font-medium">contact@willscars.com</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col items-center text-center p-6">
            <div className="h-12 w-12 rounded-full bg-bordeaux-100 flex items-center justify-center mb-4">
              <MapPin className="h-6 w-6 text-bordeaux-950" />
            </div>
            <h3 className="font-semibold mb-2">Adresse</h3>
            <p className="text-muted-foreground mb-4">Showroom ouvert du lundi au samedi</p>
            <p className="font-medium">123 Avenue des Véhicules, Abidjan</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-6">Envoyez-nous un message</h2>
          <form className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="first-name">Prénom</Label>
                <Input id="first-name" placeholder="Votre prénom" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="last-name">Nom</Label>
                <Input id="last-name" placeholder="Votre nom" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="votre@email.com" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Téléphone</Label>
              <Input id="phone" placeholder="Votre numéro de téléphone" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subject">Sujet</Label>
              <Input id="subject" placeholder="Sujet de votre message" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" placeholder="Votre message" className="min-h-[150px]" />
            </div>
            <Button type="submit" className="w-full bg-bordeaux-950 hover:bg-bordeaux-900">
              Envoyer le message
            </Button>
          </form>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <Button asChild className="flex-1 bg-bordeaux-950 hover:bg-bordeaux-900">
              <Link href="tel:+2250787854165" className="flex items-center justify-center gap-2">
                <Phone className="h-4 w-4" />
                Appeler maintenant
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="flex-1 border-bordeaux-950 text-bordeaux-950 hover:bg-bordeaux-50"
            >
              <Link
                href="https://wa.me/2250787854165"
                target="_blank"
                className="flex items-center justify-center gap-2"
              >
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </Link>
            </Button>
          </div>
        </div>

        <div className="relative h-[400px] lg:h-auto rounded-lg overflow-hidden">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d254784.1869487192!2d-4.0518375!3d5.348959!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc1ea5311959121%3A0x3fe70ddce19221a6!2sAbidjan%2C%20C%C3%B4te%20d&#39;Ivoire!5e0!3m2!1sfr!2sfr!4v1623252353221!5m2!1sfr!2sfr"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            className="absolute inset-0"
          ></iframe>
        </div>
      </div>
    </div>
  )
}
