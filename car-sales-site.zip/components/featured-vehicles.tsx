import type { Vehicle } from "@/lib/data"
import { VehicleCard } from "@/components/vehicle-card"

interface FeaturedVehiclesProps {
  vehicles: Vehicle[]
}

export function FeaturedVehicles({ vehicles }: FeaturedVehiclesProps) {
  return (
    <section className="py-12">
      <div className="container">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Véhicules en vedette</h2>
            <p className="text-muted-foreground">Découvrez notre sélection de véhicules de qualité</p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 pt-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {vehicles.slice(0, 4).map((vehicle) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} />
          ))}
        </div>
      </div>
    </section>
  )
}
