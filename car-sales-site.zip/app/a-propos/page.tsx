import { Award, Clock, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-2">À propos d'AutoMarket</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Votre partenaire de confiance pour l'achat et la vente de véhicules depuis 2005
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-2xl font-bold mb-4">Notre histoire</h2>
          <p className="text-muted-foreground mb-4">
            Fondée en 2005 par deux passionnés d'automobile, AutoMarket est née d'une vision simple : rendre l'achat de véhicules plus transparent, plus simple et plus agréable. Ce qui a commencé comme une petite concession dans la banlieue parisienne s'est transformé en l'un des leaders du marché automobile en France.
          </p>
          <p className="text-muted-foreground">
            Aujourd'hui, avec plus de 15 ans d'expérience, nous sommes fiers de notre réputation d'excellence et de notre engagement envers la satisfaction client. Notre équipe de professionnels passionnés travaille chaque jour pour vous offrir le meilleur service possible et vous aider à trouver le véhicule de vos rêves.
          </p>
        </div>
        <div className="relative aspect-video rounded-lg overflow-hidden">
          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=600')] bg-cover bg-center"></div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="flex flex-col items-center text-center p-6">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Users className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-semibold mb-2">Notre équipe</h3>
          <p className="text-muted-foreground">
            Une équipe de 50 professionnels passionnés par l'automobile et dédiés à votre satisfaction. Nos conseillers, mécaniciens et experts sont là pour vous accompagner à chaque étape.
          </p>
        </div>
        
        <div className="flex flex-col items-center text-center p-6">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Award className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-semibold mb-2">Nos valeurs</h3>
          <p className="text-muted-foreground">
            Transparence, qualité et satisfaction client sont au cœur de notre philosophie. Nous croyons en l'honnêteté et en l'établissement de relations durables avec nos clients.
          </p>
        </div>
        
        <div className="flex flex-col items-center text-center p-6">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <Clock className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-semibold mb-2">Notre engagement</h3>
          <p className="text-muted-foreground">
            Nous nous engageons à vous offrir des véhicules de qualité, rigoureusement contrôlés et préparés, avec un service client exceptionnel avant, pendant et après votre achat.
          </p>
        </div>
      </div>
      
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Notre équipe de direction</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="text-center">
              <div className="relative w-40 h-40 mx-auto rounded-full overflow-hidden mb-4">
                <div className="absolute inset-0 bg-[url('/placeholder.svg?height=160&width=160')] bg-cover bg-center"></div>
              </div>
              <h3 className="font-semibold">Jean Dupont</h3>
              <p className="text-sm text-muted-foreground">Directeur Général</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-muted p-8 rounded-lg">
        <h2 className="text-2xl font-bold mb-6 text-center">Nos chiffres clés</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <p className="text-4xl font-bold text-primary">15+</p>
            <p className="text-muted-foreground">Années\
