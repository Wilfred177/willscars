import { HeroSection } from "@/components/hero-section"
import { SellSection } from "@/components/sell-section"
import { FeaturedVehicles } from "@/components/featured-vehicles"
import { vehicles } from "@/lib/data"

export default function Home() {
  return (
    <div className="flex flex-col">
      <HeroSection />
      <FeaturedVehicles vehicles={vehicles} />
      <SellSection />
    </div>
  )
}
