import Link from "next/link"
import Image from "next/image"
import { Facebook, MessageCircle } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="border-t bg-background">
      <div className="container flex flex-col gap-8 py-8 md:flex-row md:py-12">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="relative h-10 w-10 overflow-hidden rounded-md">
              <Image src="/logo.png" alt="Will's Cars Logo" fill className="object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-none">Will's</span>
              <span className="font-bold text-lg leading-none">Cars</span>
              <span className="text-xs text-muted-foreground leading-none">LUXURY</span>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Votre partenaire de confiance pour l'achat et la vente de véhicules de luxe.
          </p>
          <div className="mt-4 flex items-center gap-4">
            <Link
              href="https://www.facebook.com/share/1EQRmsHw3x/?mibextid=wwXIfr"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-rollsroyce"
            >
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link
              href="https://www.tiktok.com/@leandre.yapi?_t=ZM-8x9t8DdRmbA&_r=1"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-rollsroyce"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
                <path d="M15 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                <path d="M15 2v20" />
                <path d="M9 16v6" />
                <path d="M9 12V8c0-2.2 1.8-4 4-4" />
              </svg>
              <span className="sr-only">TikTok</span>
            </Link>
            <Link
              href={`https://wa.me/2250787854165`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-rollsroyce"
            >
              <MessageCircle className="h-5 w-5" />
              <span className="sr-only">WhatsApp</span>
            </Link>
          </div>
        </div>
        <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-medium">Navigation</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li>
                <Link href="/">Accueil</Link>
              </li>
              <li>
                <Link href="/vehicules">Véhicules</Link>
              </li>
              <li>
                <Link href="/ajouter-vehicule">Ajouter un véhicule</Link>
              </li>
              <li>
                <Link href="/contact">Contact</Link>
              </li>
            </ul>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-medium">Catégories</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li>
                <Link href="/vehicules?type=berline">Berlines</Link>
              </li>
              <li>
                <Link href="/vehicules?type=suv">SUV</Link>
              </li>
              <li>
                <Link href="/vehicules?type=cabriolet">Cabriolets</Link>
              </li>
              <li>
                <Link href="/vehicules?type=luxe">Véhicules de luxe</Link>
              </li>
            </ul>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-medium">Services</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li>
                <Link href="/financement">Financement</Link>
              </li>
              <li>
                <Link href="/assurance">Assurance</Link>
              </li>
              <li>
                <Link href="/garantie">Garantie</Link>
              </li>
              <li>
                <Link href="/entretien">Entretien</Link>
              </li>
            </ul>
          </div>
          <div className="flex flex-col gap-2">
            <h4 className="text-sm font-medium">Contact</h4>
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              <li>
                <Link href="tel:+2250787854165">+225 07 8785 4165</Link>
              </li>
              <li>
                <Link href="https://wa.me/2250787854165" target="_blank">
                  WhatsApp
                </Link>
              </li>
              <li>
                <Link href="mailto:contact@willscars.com">contact@willscars.com</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="container border-t py-6">
        <p className="text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Will's Cars. Tous droits réservés.
        </p>
      </div>
    </footer>
  )
}
