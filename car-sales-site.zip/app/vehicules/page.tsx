import { Suspense } from "react"
import { FilterSidebar } from "@/components/filter-sidebar"
import { VehicleCard } from "@/components/vehicle-card"
import { getFilteredVehicles } from "@/lib/data"

interface VehiclesPageProps {
  searchParams: {
    make?: string
    minPrice?: string
    maxPrice?: string
    minYear?: string
    maxYear?: string
    fuelType?: string
  }
}

export default function VehiclesPage({ searchParams }: VehiclesPageProps) {
  const { make, minPrice, maxPrice, minYear, maxYear, fuelType } = searchParams

  const filteredVehicles = getFilteredVehicles({
    make,
    minPrice: minPrice ? Number.parseInt(minPrice) : undefined,
    maxPrice: maxPrice ? Number.parseInt(maxPrice) : undefined,
    minYear: minYear ? Number.parseInt(minYear) : undefined,
    maxYear: maxYear ? Number.parseInt(maxYear) : undefined,
    fuelType,
  })

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Nos véhicules</h1>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
        <div className="md:col-span-1">
          <div className="sticky top-24">
            <FilterSidebar />
          </div>
        </div>

        <div className="md:col-span-3">
          <Suspense fallback={<div>Chargement...</div>}>
            {filteredVehicles.length > 0 ? (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {filteredVehicles.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold mb-2">Aucun véhicule trouvé</h2>
                <p className="text-muted-foreground">Essayez de modifier vos critères de recherche</p>
              </div>
            )}
          </Suspense>
        </div>
      </div>
    </div>
  )
}
