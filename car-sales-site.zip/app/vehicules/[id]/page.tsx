import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Calendar, Car, Fuel, Gauge, Info, Mail, MessageCircle, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CommentSection } from "@/components/comment-section"
import { getVehicleById, vehicles } from "@/lib/data"

interface VehiclePageProps {
  params: {
    id: string
  }
}

export function generateStaticParams() {
  return vehicles.map((vehicle) => ({
    id: vehicle.id,
  }))
}

export default function VehiclePage({ params }: VehiclePageProps) {
  const vehicle = getVehicleById(params.id)

  if (!vehicle) {
    notFound()
  }

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/vehicules" className="text-sm text-muted-foreground hover:underline">
          ← Retour aux véhicules
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold mb-2">
            {vehicle.make} {vehicle.model} ({vehicle.year})
          </h1>
          <p className="text-xl font-semibold text-bordeaux-950 mb-6">{vehicle.price.toLocaleString()} FCFA</p>

          <div className="relative aspect-[16/9] overflow-hidden rounded-lg mb-4">
            <Image
              src={vehicle.images[0] || "/placeholder.svg"}
              alt={`${vehicle.make} ${vehicle.model}`}
              fill
              className="object-cover"
            />
          </div>

          <div className="grid grid-cols-3 gap-4 mb-8">
            {vehicle.images.slice(1, 4).map((image, index) => (
              <div key={index} className="relative aspect-[4/3] overflow-hidden rounded-lg">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${vehicle.make} ${vehicle.model} - Vue ${index + 2}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>

          <Tabs defaultValue="details">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="details">Détails</TabsTrigger>
              <TabsTrigger value="features">Équipements</TabsTrigger>
              <TabsTrigger value="description">Description</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="p-4 border rounded-md mt-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Marque</p>
                    <p className="font-medium">{vehicle.make}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Modèle</p>
                    <p className="font-medium">{vehicle.model}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Année</p>
                    <p className="font-medium">{vehicle.year}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Kilométrage</p>
                    <p className="font-medium">{vehicle.mileage.toLocaleString()} km</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Fuel className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Carburant</p>
                    <p className="font-medium">{vehicle.fuelType}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Transmission</p>
                    <p className="font-medium">{vehicle.transmission}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Couleur</p>
                    <p className="font-medium">{vehicle.color}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Type de carrosserie</p>
                    <p className="font-medium">{vehicle.bodyType}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Moteur</p>
                    <p className="font-medium">{vehicle.engineSize}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-bordeaux-950" />
                  <div>
                    <p className="text-sm text-muted-foreground">Portes</p>
                    <p className="font-medium">{vehicle.doors}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="features" className="p-4 border rounded-md mt-2">
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {vehicle.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-bordeaux-950" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>
            <TabsContent value="description" className="p-4 border rounded-md mt-2">
              <p className="whitespace-pre-line">{vehicle.description}</p>
            </TabsContent>
          </Tabs>

          <CommentSection />
        </div>

        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Intéressé par ce véhicule ?</CardTitle>
              <CardDescription>Contactez-nous pour plus d'informations ou pour organiser un essai</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-bordeaux-950" />
                <div>
                  <p className="text-sm text-muted-foreground">Téléphone</p>
                  <p className="font-medium">+225 07 8785 4165</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="h-5 w-5 text-bordeaux-950" />
                <div>
                  <p className="text-sm text-muted-foreground">WhatsApp</p>
                  <p className="font-medium">+225 07 8785 4165</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-bordeaux-950" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">contact@willscars.com</p>
                </div>
              </div>
              <Button className="w-full bg-bordeaux-950 hover:bg-bordeaux-900">
                <Link href="tel:+2250787854165">Appeler maintenant</Link>
              </Button>
              <Button variant="outline" className="w-full border-bordeaux-950 text-bordeaux-950 hover:bg-bordeaux-50">
                <Link href="https://wa.me/2250787854165" target="_blank" className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4" />
                  Contacter sur WhatsApp
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Financement</CardTitle>
              <CardDescription>Simulation de financement pour ce véhicule</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Prix du véhicule</span>
                  <span className="font-medium">{vehicle.price.toLocaleString()} FCFA</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Durée</span>
                  <span className="font-medium">60 mois</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Taux d'intérêt</span>
                  <span className="font-medium">3.9%</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="font-semibold">Mensualité estimée</span>
                  <span className="font-semibold text-bordeaux-950">
                    {Math.round((vehicle.price / 60) * 1.039).toLocaleString()} FCFA/mois
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  * Simulation non contractuelle, sous réserve d'acceptation de votre dossier
                </p>
                <Button variant="outline" className="w-full border-bordeaux-950 text-bordeaux-950 hover:bg-bordeaux-50">
                  Demander un financement
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Suivez-nous</CardTitle>
              <CardDescription>Retrouvez-nous sur les réseaux sociaux</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center gap-4">
                <Button asChild variant="outline" size="lg" className="flex-1">
                  <Link
                    href="https://www.facebook.com/share/1EQRmsHw3x/?mibextid=wwXIfr"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5"
                    >
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                    </svg>
                    Facebook
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="flex-1">
                  <Link
                    href="https://www.tiktok.com/@leandre.yapi?_t=ZM-8x9t8DdRmbA&_r=1"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5"
                    >
                      <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
                      <path d="M15 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                      <path d="M15 2v20" />
                      <path d="M9 16v6" />
                      <path d="M9 12V8c0-2.2 1.8-4 4-4" />
                    </svg>
                    TikTok
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
