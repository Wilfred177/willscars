export type Vehicle = {
  id: string
  make: string
  model: string
  year: number
  price: number
  mileage: number
  fuelType: string
  transmission: string
  color: string
  images: string[]
  description: string
  features: string[]
  condition: string
  bodyType: string
  engineSize: string
  doors: number
  sold: boolean
}

export const vehicles: Vehicle[] = [
  {
    id: "1",
    make: "Renault",
    model: "Clio",
    year: 2022,
    price: 12135204, // 18500 * 655.957
    mileage: 15000,
    fuelType: "Essence",
    transmission: "Manuelle",
    color: "Rouge",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Renault Clio en excellent état. Première main, entretien régulier, faible kilométrage. Parfaite pour la ville avec sa consommation économique et sa facilité de stationnement.",
    features: ["Climatisation", "Bluetooth", "Régulateur de vitesse", "Capteurs de stationnement", "Écran tactile"],
    condition: "Excellent",
    bodyType: "Berline",
    engineSize: "1.0L",
    doors: 5,
    sold: false,
  },
  {
    id: "2",
    make: "Peugeot",
    model: "3008",
    year: 2021,
    price: 19613115, // 29900 * 655.957
    mileage: 25000,
    fuelType: "Diesel",
    transmission: "Automatique",
    color: "Gris",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Peugeot 3008 SUV spacieux et confortable. Idéal pour les familles avec son grand coffre et ses équipements de sécurité avancés. Finition GT Line avec sièges en cuir et toit panoramique.",
    features: ["GPS", "Caméra de recul", "Toit panoramique", "Sièges chauffants", "Apple CarPlay/Android Auto"],
    condition: "Très bon",
    bodyType: "SUV",
    engineSize: "1.6L",
    doors: 5,
    sold: false,
  },
  {
    id: "3",
    make: "Citroën",
    model: "C3",
    year: 2020,
    price: 9511376, // 14500 * 655.957
    mileage: 35000,
    fuelType: "Essence",
    transmission: "Manuelle",
    color: "Bleu",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Citroën C3 compacte et économique. Parfaite pour la ville avec sa maniabilité et son faible coût d'entretien. Version Feel avec équipements modernes et confort optimal.",
    features: ["Climatisation", "Bluetooth", "Limiteur de vitesse", "Airbags", "Système audio"],
    condition: "Bon",
    bodyType: "Citadine",
    engineSize: "1.2L",
    doors: 5,
    sold: false,
  },
  {
    id: "4",
    make: "Volkswagen",
    model: "Golf",
    year: 2019,
    price: 12987948, // 19800 * 655.957
    mileage: 45000,
    fuelType: "Diesel",
    transmission: "Manuelle",
    color: "Noir",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Volkswagen Golf, la référence des compactes. Fiabilité allemande et performances remarquables. Version Confortline avec équipements premium et finitions soignées.",
    features: [
      "Climatisation automatique",
      "Système navigation",
      "Régulateur adaptatif",
      "Phares LED",
      "Détecteur d'angles morts",
    ],
    condition: "Bon",
    bodyType: "Compacte",
    engineSize: "2.0L TDI",
    doors: 5,
    sold: false,
  },
  {
    id: "5",
    make: "BMW",
    model: "Série 3",
    year: 2021,
    price: 27550194, // 42000 * 655.957
    mileage: 20000,
    fuelType: "Hybride",
    transmission: "Automatique",
    color: "Blanc",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "BMW Série 3 hybride alliant performances et économie. Finition M Sport avec équipements haut de gamme et technologie de pointe. Conduite dynamique et confort premium.",
    features: [
      "Cuir",
      "Toit ouvrant",
      "Système audio Harman Kardon",
      "Assistance au stationnement",
      "Affichage tête haute",
    ],
    condition: "Excellent",
    bodyType: "Berline",
    engineSize: "2.0L",
    doors: 4,
    sold: false,
  },
  {
    id: "6",
    make: "Mercedes",
    model: "Classe A",
    year: 2020,
    price: 21318602, // 32500 * 655.957
    mileage: 30000,
    fuelType: "Essence",
    transmission: "Automatique",
    color: "Gris métallisé",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Mercedes Classe A, le luxe compact. Intérieur raffiné avec système MBUX et écran panoramique. Performances et confort exceptionnels pour une conduite premium au quotidien.",
    features: ["Système MBUX", "Écrans numériques", "Éclairage d'ambiance", "Sièges sport", "Suspension adaptative"],
    condition: "Très bon",
    bodyType: "Compacte",
    engineSize: "1.8L",
    doors: 5,
    sold: false,
  },
  {
    id: "7",
    make: "Audi",
    model: "Q5",
    year: 2019,
    price: 25516728, // 38900 * 655.957
    mileage: 40000,
    fuelType: "Diesel",
    transmission: "Automatique",
    color: "Noir",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Audi Q5, le SUV premium par excellence. Technologie Quattro pour une adhérence optimale en toutes conditions. Finition S Line avec équipements sportifs et luxueux.",
    features: ["Quattro", "Matrix LED", "Virtual Cockpit", "Bang & Olufsen", "Assistance à la conduite"],
    condition: "Bon",
    bodyType: "SUV",
    engineSize: "2.0L TDI",
    doors: 5,
    sold: false,
  },
  {
    id: "8",
    make: "Toyota",
    model: "Yaris",
    year: 2022,
    price: 11741630, // 17900 * 655.957
    mileage: 10000,
    fuelType: "Hybride",
    transmission: "Automatique",
    color: "Rouge",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Toyota Yaris hybride, économique et écologique. Consommation réduite et émissions minimales. Parfaite pour la ville avec sa taille compacte et sa maniabilité exceptionnelle.",
    features: ["Système hybride", "Caméra de recul", "Toyota Safety Sense", "Écran tactile", "Connectivité smartphone"],
    condition: "Excellent",
    bodyType: "Citadine",
    engineSize: "1.5L Hybride",
    doors: 5,
    sold: false,
  },
]

export const getVehicleById = (id: string): Vehicle | undefined => {
  return vehicles.find((vehicle) => vehicle.id === id)
}

export const getFilteredVehicles = ({
  make,
  minPrice,
  maxPrice,
  minYear,
  maxYear,
  fuelType,
}: {
  make?: string
  minPrice?: number
  maxPrice?: number
  minYear?: number
  maxYear?: number
  fuelType?: string
}) => {
  return vehicles.filter((vehicle) => {
    if (make && vehicle.make !== make) return false
    if (minPrice && vehicle.price < minPrice) return false
    if (maxPrice && vehicle.price > maxPrice) return false
    if (minYear && vehicle.year < minYear) return false
    if (maxYear && vehicle.year > maxYear) return false
    if (fuelType && vehicle.fuelType !== fuelType) return false
    return true
  })
}

export const getUniqueValues = (field: keyof Vehicle) => {
  const values = vehicles.map((vehicle) => vehicle[field])
  return [...new Set(values)]
}
