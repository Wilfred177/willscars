import Link from "next/link"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SellSection() {
  return (
    <section className="bg-beige py-16">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Vendez votre véhicule facilement</h2>
          <p className="text-muted-foreground mb-8">
            Ajoutez des photos et vidéos de qualité pour attirer plus d'acheteurs
          </p>
          <Button asChild className="bg-rollsroyce hover:bg-rollsroyce-800">
            <Link href="/ajouter-vehicule" className="flex items-center gap-2">
              <Plus className="h-4 w-4" /> Ajouter mon véhicule
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
