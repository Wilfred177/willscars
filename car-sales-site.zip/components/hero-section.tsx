import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function HeroSection() {
  return (
    <section className="bg-rollsroyce py-16 text-white">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">Trouvez votre véhicule de luxe idéal</h1>
          <p className="text-lg text-white/80">
            Des véhicules d'exception et de prestige vous attendent chez Will's Cars
          </p>
        </div>

        <div className="max-w-3xl mx-auto bg-white/10 backdrop-blur-sm rounded-lg p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="col-span-1 md:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Marque, modèle..." className="bg-white text-black" />
                <Input placeholder="Budget max..." className="bg-white text-black" />
              </div>
            </div>
            <Button className="bg-rollsroyce hover:bg-rollsroyce-800 text-white">
              <Search className="mr-2 h-4 w-4" /> Rechercher
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mt-6">
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              Véhicules neufs
            </Button>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/20">
              Véhicules d'occasion
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
