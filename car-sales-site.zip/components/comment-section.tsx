"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MessageSquare, ThumbsUp } from "lucide-react"

interface Comment {
  id: number
  name: string
  date: string
  content: string
  likes: number
}

export function CommentSection() {
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      name: "Jean Dupont",
      date: "Il y a 2 jours",
      content:
        "Superbe véhicule ! J'ai pu l'essayer la semaine dernière et je suis vraiment impressionné par ses performances.",
      likes: 3,
    },
    {
      id: 2,
      name: "Marie Martin",
      date: "Il y a 5 jours",
      content: "Le rapport qualité-prix est excellent. Je recommande vivement !",
      likes: 1,
    },
  ])

  const [newComment, setNewComment] = useState("")
  const [name, setName] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim() || !name.trim()) return

    const comment: Comment = {
      id: comments.length + 1,
      name: name,
      date: "À l'instant",
      content: newComment,
      likes: 0,
    }

    setComments([...comments, comment])
    setNewComment("")
    setName("")
  }

  const handleLike = (id: number) => {
    setComments(comments.map((comment) => (comment.id === id ? { ...comment, likes: comment.likes + 1 } : comment)))
  }

  return (
    <div className="mt-8 border rounded-lg p-6">
      <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
        <MessageSquare className="h-5 w-5 text-bordeaux-950" />
        Commentaires ({comments.length})
      </h3>

      <div className="space-y-6 mb-8">
        {comments.map((comment) => (
          <div key={comment.id} className="border-b pb-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-medium">{comment.name}</h4>
                <p className="text-xs text-muted-foreground">{comment.date}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center gap-1 text-xs"
                onClick={() => handleLike(comment.id)}
              >
                <ThumbsUp className="h-3 w-3" />
                {comment.likes}
              </Button>
            </div>
            <p className="text-sm">{comment.content}</p>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Votre nom</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Entrez votre nom"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="comment">Votre commentaire</Label>
          <Textarea
            id="comment"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Partagez votre avis sur ce véhicule..."
            className="min-h-[100px]"
            required
          />
        </div>
        <Button type="submit" className="bg-bordeaux-950 hover:bg-bordeaux-900">
          Publier un commentaire
        </Button>
      </form>
    </div>
  )
}
