import Link from "next/link"
import Image from "next/image"
import { Fuel, Calendar, Gauge, ArrowRight } from "lucide-react"

import type { Vehicle } from "@/lib/data"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface VehicleCardProps {
  vehicle: Vehicle
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  const { id, make, model, year, price, mileage, fuelType, images } = vehicle

  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={images[0] || "/placeholder.svg"}
          alt={`${make} ${model}`}
          fill
          className="object-cover transition-transform hover:scale-105"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-lg">
              {make} {model}
            </h3>
            <p className="text-sm text-muted-foreground">{year}</p>
          </div>
          <div className="text-right">
            <p className="font-bold text-lg text-rollsroyce">{price.toLocaleString()} FCFA</p>
            <Badge variant="outline" className="mt-1 bg-rollsroyce-50 text-rollsroyce border-rollsroyce-200">
              {fuelType}
            </Badge>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4 text-rollsroyce" />
            <span>{year}</span>
          </div>
          <div className="flex items-center gap-1">
            <Fuel className="h-4 w-4 text-rollsroyce" />
            <span>{fuelType}</span>
          </div>
          <div className="flex items-center gap-1">
            <Gauge className="h-4 w-4 text-rollsroyce" />
            <span>{mileage.toLocaleString()} km</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button asChild className="w-full bg-rollsroyce hover:bg-rollsroyce-800">
          <Link href={`/vehicules/${id}`} className="flex items-center justify-center gap-2">
            Voir le détail
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
