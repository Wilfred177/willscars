import Link from "next/link"
import { Facebook, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SocialLinks() {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" size="icon" asChild>
        <Link
          href="https://www.facebook.com/share/1EQRmsHw3x/?mibextid=wwXIfr"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Facebook className="h-4 w-4" />
          <span className="sr-only">Facebook</span>
        </Link>
      </Button>
      <Button variant="outline" size="icon" asChild>
        <Link
          href="https://www.tiktok.com/@leandre.yapi?_t=ZM-8x9t8DdRmbA&_r=1"
          target="_blank"
          rel="noopener noreferrer"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
            <path d="M15 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
            <path d="M15 2v20" />
            <path d="M9 16v6" />
            <path d="M9 12V8c0-2.2 1.8-4 4-4" />
          </svg>
          <span className="sr-only">TikTok</span>
        </Link>
      </Button>
      <Button variant="outline" size="icon" asChild>
        <Link href={`https://wa.me/2250787854165`} target="_blank" rel="noopener noreferrer">
          <MessageCircle className="h-4 w-4" />
          <span className="sr-only">WhatsApp</span>
        </Link>
      </Button>
    </div>
  )
}
